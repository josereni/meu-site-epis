// 1. Catálogo de demonstração.
// Cada objeto representa um livro. Você pode editar nome, categoria, preço e descrição.
const products = [
  { id: 1, name: "Bíblia Sagrada", category: "Bíblias", price: 59.90, description: "Uma companheira para a leitura diária.", cover: "wine", coverTitle: "BÍBLIA SAGRADA" },
  { id: 2, name: "O Poder da Oração", category: "Oração", price: 34.90, description: "Reflexões para fortalecer sua vida de oração.", cover: "gold", coverTitle: "O PODER DA ORAÇÃO" },
  { id: 3, name: "Imitação de Cristo", category: "Espiritualidade", price: 42.00, description: "Um clássico da espiritualidade cristã.", cover: "green", coverTitle: "IMitação DE CRISTO" },
  { id: 4, name: "Vida dos Santos", category: "Santos", price: 49.90, description: "Histórias de fé, coragem e caridade.", cover: "rose", coverTitle: "VIDA DOS SANTOS" },
  { id: 5, name: "Salmos para Cada Dia", category: "Oração", price: 29.90, description: "Palavras bíblicas para meditar e rezar.", cover: "green", coverTitle: "SALMOS PARA CADA DIA" },
  { id: 6, name: "Conhecendo a Fé Católica", category: "Espiritualidade", price: 39.90, description: "Uma introdução aos fundamentos da fé.", cover: "gold", coverTitle: "FÉ CATÓLICA" },
  { id: 7, name: "Bíblia de Estudo", category: "Bíblias", price: 89.90, description: "Uma edição de exemplo para estudo pessoal.", cover: "wine", coverTitle: "BÍBLIA DE ESTUDO" },
  { id: 8, name: "O Santo Rosário", category: "Santos", price: 24.90, description: "Um guia simples para rezar o rosário.", cover: "rose", coverTitle: "O SANTO ROSÁRIO" }
];

// 2. Guardamos os elementos HTML que o JavaScript vai atualizar.
const productGrid = document.querySelector("#product-grid");
const searchInput = document.querySelector("#search-input");
const categoryFilter = document.querySelector("#category-filter");
const emptyState = document.querySelector("#empty-state");
const cartPanel = document.querySelector("#cart-panel");
const cartBackdrop = document.querySelector("#cart-backdrop");
const cartItems = document.querySelector("#cart-items");
const cartCount = document.querySelector("#cart-count");
const cartTotal = document.querySelector("#cart-total");

// 3. O carrinho guarda os produtos escolhidos e suas quantidades.
const CART_STORAGE_KEY = "livraria-santa-fe-cart-v1";
let cart = [];

// Recupera o carrinho salvo neste navegador, sem impedir o site de abrir
// caso o armazenamento esteja indisponível.
try {
  const savedCart = JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || "[]");
  if (Array.isArray(savedCart)) {
    cart = savedCart.filter((saved) =>
      products.some((product) => product.id === saved.id) &&
      Number.isInteger(saved.quantity) && saved.quantity > 0
    ).map((saved) => ({
      ...products.find((product) => product.id === saved.id),
      quantity: saved.quantity
    }));
  }
} catch (error) {
  console.warn("Não foi possível recuperar o carrinho salvo.", error);
}

// 4. Formata valores como moeda brasileira.
function formatPrice(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

// 5. Mostra os livros na página. A busca e o filtro escolhem quais aparecem.
function renderProducts() {
  const searchTerm = searchInput.value.trim().toLocaleLowerCase("pt-BR");
  const chosenCategory = categoryFilter.value;

  const filteredProducts = products.filter((product) => {
    const matchesSearch = `${product.name} ${product.category} ${product.description}`
      .toLocaleLowerCase("pt-BR").includes(searchTerm);
    const matchesCategory = chosenCategory === "todos" || product.category === chosenCategory;
    return matchesSearch && matchesCategory;
  });

  productGrid.innerHTML = filteredProducts.map((product) => `
    <article class="product-card">
      <div class="cover ${product.cover}">
        <div class="cover-inner">
          <strong>${product.coverTitle}</strong>
          <small>LIVRARIA SANTA FÉ</small>
        </div>
      </div>
      <p class="product-category">${product.category}</p>
      <h3>${product.name}</h3>
      <p class="product-description">${product.description}</p>
      <div class="product-bottom">
        <strong class="product-price">${formatPrice(product.price)}</strong>
        <button class="add-button" type="button" data-add="${product.id}">Adicionar +</button>
      </div>
    </article>
  `).join("");

  emptyState.hidden = filteredProducts.length !== 0;
}

// 6. Adiciona um livro ao carrinho. Se já existir, aumenta a quantidade.
function addToCart(productId) {
  const product = products.find((item) => item.id === productId);
  const existingItem = cart.find((item) => item.id === productId);

  if (!product) return;
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }
  renderCart();
}

// 7. Desenha os itens, as quantidades e o valor total do carrinho.
function renderCart() {
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  cartCount.textContent = totalItems;
  cartTotal.textContent = formatPrice(totalPrice);
  try {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  } catch (error) {
    console.warn("Não foi possível salvar o carrinho neste navegador.", error);
  }

  if (cart.length === 0) {
    cartItems.innerHTML = '<p class="cart-empty">Seu carrinho está vazio. Escolha um livro para começar.</p>';
    return;
  }

  cartItems.innerHTML = cart.map((item) => `
    <div class="cart-line">
      <div>
        <strong>${item.name}</strong>
        <small>${formatPrice(item.price)} cada</small>
        <div class="quantity-controls">
          <button type="button" data-decrease="${item.id}" aria-label="Diminuir quantidade">−</button>
          <span>${item.quantity}</span>
          <button type="button" data-increase="${item.id}" aria-label="Aumentar quantidade">+</button>
        </div>
      </div>
      <button class="remove-button" type="button" data-remove="${item.id}">Remover</button>
    </div>
  `).join("");
}

// 8. Abre e fecha o painel do carrinho.
function openCart() {
  cartPanel.classList.add("is-open");
  cartPanel.setAttribute("aria-hidden", "false");
  cartBackdrop.hidden = false;
}
function closeCart() {
  cartPanel.classList.remove("is-open");
  cartPanel.setAttribute("aria-hidden", "true");
  cartBackdrop.hidden = true;
}

// 9. Os eventos percebem cliques e mudanças do visitante.
productGrid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-add]");
  if (button) addToCart(Number(button.dataset.add));
});

cartItems.addEventListener("click", (event) => {
  const increaseButton = event.target.closest("[data-increase]");
  const decreaseButton = event.target.closest("[data-decrease]");
  const removeButton = event.target.closest("[data-remove]");

  if (increaseButton) {
    const item = cart.find((product) => product.id === Number(increaseButton.dataset.increase));
    if (item) item.quantity += 1;
  }
  if (decreaseButton) {
    const item = cart.find((product) => product.id === Number(decreaseButton.dataset.decrease));
    if (item) item.quantity -= 1;
    const index = cart.findIndex((product) => product.quantity <= 0);
    if (index !== -1) cart.splice(index, 1);
  }
  if (removeButton) {
    const index = cart.findIndex((product) => product.id === Number(removeButton.dataset.remove));
    if (index !== -1) cart.splice(index, 1);
  }
  renderCart();
});

searchInput.addEventListener("input", renderProducts);
categoryFilter.addEventListener("change", renderProducts);
document.querySelector("#open-cart").addEventListener("click", openCart);
document.querySelector("#close-cart").addEventListener("click", closeCart);
cartBackdrop.addEventListener("click", closeCart);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeCart();
});

// 10. Prepara o pedido para envio pelo WhatsApp.
// Antes de publicar para clientes, troque o número abaixo pelo WhatsApp comercial.
const WHATSAPP_NUMBER = ""; // Exemplo: "5511999999999" (somente números)

document.querySelector("#checkout-button").addEventListener("click", () => {
  if (cart.length === 0) {
    alert("Seu carrinho está vazio. Adicione um livro antes de preparar o pedido.");
    return;
  }

  const summary = cart.map((item) =>
    `${item.quantity}x ${item.name} — ${formatPrice(item.price * item.quantity)}`
  ).join("\n");
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const message = `Olá! Gostaria de consultar este pedido:\n\n${summary}\n\nTotal demonstrativo: ${formatPrice(total)}\n\nPoderiam confirmar disponibilidade e valor final?`;

  if (!/^\d{10,15}$/.test(WHATSAPP_NUMBER)) {
    alert(`Pedido preparado:\n\n${summary}\n\nTotal demonstrativo: ${formatPrice(total)}\n\nPara enviar pelo WhatsApp, configure o número comercial na constante WHATSAPP_NUMBER, no arquivo script.js.`);
    return;
  }

  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
});

// 11. Ano automático no rodapé e primeira renderização.
document.querySelector("#current-year").textContent = new Date().getFullYear();
renderProducts();
renderCart();
