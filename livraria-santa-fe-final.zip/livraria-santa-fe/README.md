# Livraria Santa Fé

Site de demonstração de uma livraria católica, feito com HTML, CSS e JavaScript puro.

## Arquivos

- `index.html` — estrutura e conteúdo da página.
- `style.css` — cores, fontes, espaçamento e adaptação para celular.
- `script.js` — catálogo demonstrativo, busca, filtro, carrinho salvo no navegador e preparação de pedido pelo WhatsApp após configurar o número comercial.
- `README.md` — instruções do projeto.

## Como abrir no VS Code

1. Extraia o arquivo ZIP para uma pasta do seu computador.
2. Abra o VS Code.
3. Clique em **Arquivo > Abrir Pasta** e escolha a pasta `livraria-santa-fe`.
4. Abra `index.html`.
5. Se você tiver a extensão **Live Server**, clique com o botão direito em `index.html` e selecione **Open with Live Server**. Se não tiver, pode abrir o arquivo `index.html` diretamente no navegador para testar as funções básicas.

## Como personalizar

- Edite os livros no começo de `script.js`, dentro da lista `products`.
- Mude as cores no começo de `style.css`, dentro de `:root`.
- Troque o nome, os textos e os links em `index.html`.
- No arquivo `script.js`, preencha a constante `WHATSAPP_NUMBER` com o número comercial completo, incluindo código do país e DDD, sem `+`, espaços ou traços. No HTML, atualize também a área de contato com os dados comerciais reais.

## Publicar no GitHub Pages

1. Entre na sua conta do GitHub e crie um repositório público chamado `livraria-santa-fe`.
2. Envie os arquivos `index.html`, `style.css`, `script.js` e `README.md` para a raiz do repositório.
3. No repositório, abra **Settings > Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde a publicação e abra o endereço indicado na área **Pages**.

## Importante

Este é um protótipo educativo: os produtos e preços são exemplos; o carrinho é salvo localmente no navegador do visitante, mas não existe banco de dados nem painel administrativo. O botão de pedido não processa pagamentos. Antes de vender, confirme os produtos e preços reais, configure um WhatsApp comercial e planeje como receber pedidos, tratar dados dos clientes e receber pagamentos com segurança.


## Verificações antes de vender

- Substitua os livros, preços e descrições de demonstração por informações reais.
- Configure o WhatsApp comercial em `script.js` e atualize o contato no `index.html`.
- Teste busca, filtros, inclusão/remoção de itens e total do carrinho.
- O site ainda não recebe pagamentos nem registra pedidos em servidor. Para uma loja real, será necessário integrar um serviço seguro de pagamento e definir política de privacidade, entrega e atendimento.
